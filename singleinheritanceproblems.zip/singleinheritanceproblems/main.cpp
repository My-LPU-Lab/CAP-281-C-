#include <iostream>

using namespace std;

class Circle
{
    int r;
   public:
    Circle(int x)
    {
        r=x;
    }

    void display()
    {
        cout<<"The area of circle is: "<<3.14f*r*r<<endl;
    }
};


class Rectangle: public Circle
{
    int l,b;

    public:
        Rectangle(int y, int z): Circle(y)
        {
            l=y;
            b=z;
        }

        void result()
        {
            cout<<"The area of the rectangle is: "<<l*b;
        }
};

int main()
{
    //cout << "Hello world!" << endl;
    int num1, num2;
    cout<<"Please enter the dimensions of the rectangle ";
    cin>> num1>> num2;
    Rectangle obj(num1,num2);
    obj.display();
    obj.result();

    return 0;
}
