#include <iostream>
using namespace std;

class C
{
    int r;
    float area;
    void calC();

public:
    void getval(int x)
    {
        r = x;
    }

    void display()
    {
        calC();
        cout<<"Pointer object area: "<<area<<endl;
    }

    friend void AreaC(C);
};

void C::calC()
{
    area = 3.14*r*r;
}

void AreaC(C obj)
{
    C *p1  = &obj;
    int (C::*ptr) = &C::r;
    float a;
    a = 3.14* (*p1).*ptr * (*p1).*ptr;
    cout<<a;
}

int main()
{
    C obj;
    C *p = &obj;
    int r;
    cout<<"Enter radius: ";
    cin>>r;
    obj.getval(r);
   // (*p).display();
   void (C::*p2)(void) = &C::display;
   (obj.*p2)();
    AreaC(*p);



    //cout << "Hello world!" << endl;
    return 0;
}
