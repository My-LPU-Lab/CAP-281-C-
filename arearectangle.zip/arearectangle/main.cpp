#include <iostream>

using namespace std;

class Rect
{
    int a,b;
    int result;
    void calcA();

public:

    void getval(int x, int y)
    {
        a = x;
        b = y;
    }

    void display()
    {
        calcA();
        cout<<"Pointer to member function: "<<result<<endl;
    }

   //friend int
};
void Rect::calcA()
{
    result = a * b;
}


/*int CalArea(Rect ob)
{

}
*/
int main()
{
    Rect obj;
    Rect *p = &obj;
    int w,l;

    cout << "Please enter the width and length of rectangle: ";
    cin>>w>>l;

   void (Rect::*p1)(int,int) = &Rect::getval;
   (obj.*p1)(w,l);

    void (Rect::*p2)(void) = &Rect::display;
    (obj.*p2)();

    return 0;
}
