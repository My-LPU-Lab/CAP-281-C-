#include <iostream>
using namespace std;

class A;

class B
{
    int b;

public:
    B(int y1)
    {
        b = y1;
    }
friend class A;
};

class A
{
    int a;

public:
    A(int y)
    {
        a = y;
    }

    int gnum(B);
};

A::gnum(B obj)
{
    if(a>obj.b)
    {
        return a;
    }else{
        return obj.b;
    }
}



int main()
{
   A obj(10);
   B obj1(20);

   int r;
   r= obj.gnum(obj1);
   cout<<r;
}
