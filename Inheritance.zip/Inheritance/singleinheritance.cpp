#include <iostream>
using namespace std;

class student
{
private:
    int age;
    char name[10];

public:

    void get()
    {
        cout<<"Enter student name: ";
        cin>> name;

        cout<<"\nPlease enter student age: ";
        cin>> age;
    }

    void show()
    {
        cout<< "The name of student "<< name << " and the age is "<<age << endl;
    }
};

class teacher: public student
{
private:
    int count;
public:
    void get()
    {
        student::get();

        cout<<"\nHow students do you teach: ";
        cin>> count;
    }
    void show()
    {
        student::show();
        cout<<"\nThe number of students I teach is: "<<count;
    }
};
/*
int main()
{
    teacher obj;
    obj.get();
    obj.show();

    return 0;
}
*/
