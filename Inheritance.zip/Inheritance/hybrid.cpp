#include<iostream>
using namespace std;

class student
{
  protected:
    int r_no;

  public:
    void getRollno()
    {
      cout << "Enter the roll number: ";
      cin >> r_no;
    }

    void ShowRollno()
    {
      cout << "\nRoll Number is: " << r_no << "\n";
    }
};

class test : public student
//intermediate base class
{
  protected:
    int CA, Mid, EndT;

  public:
    void getMarks()
    {
      cout << "Enter score for CA : ";
      cin >> CA;
      cout << "Enter score for Mid Exam: ";
      cin >> Mid;
      cout<< "Enter score for End Term Exam: ";
      cin>> EndT;
    }

    void DisplayMarks()
    {
      cout << "SCORE OBTAINED FOR TERM 1  " << "\n";
	  cout << "  CA: " << CA;
      cout << "\n  Mid Term: " << Mid ;
      cout << "\n  End Term: " << EndT << "\n";
    }
};

class sports
{
  protected:
    char option[10];

  public:
    void getSports()
    {
      cout << "Do you play football. Answer with [Yes] or [No] : ";
      cin >> option;
    }

    void ShowSports()
    {
      cout << "Do you play football? : " << option << "\n \n";
    }
};

class result : public test, public sports    //derived from test and sports
{
  int total;

  public:
    void display ()
    {
      total = CA + Mid + EndT;
      ShowRollno();
      DisplayMarks();
      ShowSports();

      cout << "Total test  score is : " << total ;
    }
};
/*
int main ()
{
  result s1;
  s1.getRollno();
  s1.getMarks();
  s1.getSports();
  s1.display();

  return 0;
}
*/
