#include <iostream>
using namespace std;
// Base class
class Shape {
protected:
  int width;
  int height;
public:
  void setWidth(int w) {
    width = w;
  }
  void setHeight(int h) {
    height = h;
  }
};

// Derived class
class Rectangle: public Shape {
  public:
  int getArea() {
    return (width * height);
  }
};

/*
int main() {
    int w, h;
  Rectangle Rect;
  cout<<"Enter width of rectangle: ";
  cin>>w;
  Rect.setWidth(w);
  cout<<"Enter height of rectangle: ";
  cin>>h;
  Rect.setHeight(h);
  // Print the area of the object.
  cout << "The area of rectangle is : " << Rect.getArea() << endl;

  return 0;
}
*/
