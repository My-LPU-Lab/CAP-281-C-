#include <iostream>

using namespace std;

int add()
{
    cout << "Hello world!" << endl;
    return 0;
}
