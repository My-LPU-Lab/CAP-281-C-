
#include<iostream>
using namespace std;

class bio
{
  int rollno;
  char name [20];

  public:
    void get()
    {
      cout << "Please enter your name here : ";
      cin >> name;
      cout << "Please enter your roll number : ";
      cin >> rollno;
    }
    void show()
    {
      cout << "\n Student name is: " << name;
      cout << "\n Class roll number is:  " << rollno;
    }
};

class department : public bio
{
  char dept[30];
  char course [20];

  public:
    void get()
    {
      cout << "Which department are you? : ";
      cin >> dept;
      cout << "What course are you studying : ";
      cin >> course;
    }
    void show()
    {
      cout << "\n Student department is: " << dept;
      cout << "\n Student course is: " << course;
    }
};

class oop : public department
{
  int score;
  char exam [20];

  public:
    void get()
    {
      bio :: get();
      department :: get();
      cout << "Enter Test Name: ";
      cin >> exam;
      cout << "Enter test score : ";
      cin >> score;
    }
    void show()
    {
      bio :: show();
      department :: show();
      cout << "\n Test name is " << exam;
      cout << "\n Test score is " << score;
    }
};
/*
int main ()
{
  oop obj;
  obj.get();
  obj.show();
}
*/
