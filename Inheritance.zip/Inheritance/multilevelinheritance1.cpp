#include <iostream>
using namespace std;


class Cube
{
    protected:
        int width;
    public:
        void get_width(int w)
        {
            width=w;
        }

        void disp_width()
        {
            cout << "Width of cube: " << width << endl;
        }
};


class Rectangle: public Cube
{
    protected:
        int length;
    public:

        void get_length(int w, int l)
        {

            get_width(w);
            length=l;
        }

        void disp_length()
        {

            disp_width();
            cout << "Length of Cube: " << length << endl;
        }
        int area()
        {
            return width*length;
        }


};

class Volume: public Rectangle
{
    private:
        int height;
    public:

        void get_volume(int w, int l,int h)
        {

            get_length(w,l);
            height=h;
        }
        void display_heigt()
        {
            cout<<"\nThe height of Cube is: "<< height<<endl;
        }

        void disp_volume()
        {

            disp_length();
            cout << "The volume of cube is : " << area()*height << endl;
        }
};

int main()
{

    Volume obj;

    obj.get_volume(10,20,30);
    obj.display_heigt();
    obj.disp_volume();

    return 0;
}
