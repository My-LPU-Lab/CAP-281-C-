#include <iostream>

using namespace std;

class father
{
  int age;
  char name [20];

  public:
    void get()
    {
      cout << "Enter your father's name:";
      cin >> name;
      cout << "Enter your father's age:";
      cin >> age;
    }
    void show()
    {
      cout << "\n Your father's name is " << name;
	  cout << "\n Your father's age is " << age;
  }
};

class mother
{
  int age;
  char name [20];

  public:
    void get()
    {
      cout << "Enter your mother's name:";
      cin >> name;
      cout << "Enter your mother's age:";
      cin >> age;
    }
    void show()
    {
      cout << "\n Your mother's name is " << name;
      cout << "\n Your mother's age is " << age;
    }
};

class daughter : public father, public mother
{
  int yr;
  char name [20];

  public:
    void get()
    {
      father :: get();
      mother :: get();

      cout << "Enter the child's name:";
      cin >> name;
      cout << "Enter the child's year of birth:";
      cin >> yr;
    }
    void show()
    {
      father :: show();
      mother :: show();

      cout << "\n Child's name is " << name;
      cout << "\n Child's year of birth is " << yr;
    }
};

/*
int main ()
{
   daughter d1;
  d1.get();
  d1.show();
}
*/
