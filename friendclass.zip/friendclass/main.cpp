#include <iostream>
using namespace std;

class num2;
class num1
{
    int a;

public:
    num1(int y)
    {
         a = y;
    }
    int greaternum(num2);



};

class num2
{
    friend class num1;

private:
    int b;

public:
    num2(int x)
    {
        b = x;
    }

};

int num1::greaternum(num2 obj)
{
    if(a>obj.b)
    {
        return a;
    }else{
        return obj.b;
    }
}

int main()
{
    int var1, var2;
    cout<<"Enter first num: ";
    cin>>var1;
    cout<<"Enter first num: ";
    cin>>var2;
    num1 ob(var1);
    num2 ob1(var2);
    int great;
    great = ob.greaternum(ob1);
    cout <<"The greater number is "<< great << endl;
    return 0;
}
